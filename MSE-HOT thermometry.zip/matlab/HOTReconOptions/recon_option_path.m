%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file is used in constructing MSE-HOT data
%
% Ryan M Davis.             rmd12@duke.edu                       09/09/2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%end%header


function path=recon_option_path

path='C:\Users\Ryan2\Documents\MATLAB\HOTReconOptions\HOTReconOptions.mat';