% In order to run this code you must take the following steps:
% 1) open the file ~\MSE-HOT thermometry\matlab\hotPath.m and on line 5 add
% the location of the "MSE-HOT thermometry" folder that you just downloaded
% 2) open the file ~\MSE-HOT thermometry\scripts\RMD276.m and execute this
% script and let me know if the code runs.